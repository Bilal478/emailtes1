<!-- IMPORTANT: please read the New Issue Checklist before creating a new issue: https://github.com/jackocnr/intl-tel-input/wiki/New-Issue-Checklist -->

### Steps to reproduce
1.  
2.  
3.  

### Expected behaviour
Tell us what should happen

### Actual behaviour
Tell us what actually happens

### Initialisation options
List any options you're using e.g. utilsScript or preferredCountries
